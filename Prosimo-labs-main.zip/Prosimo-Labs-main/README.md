# Prosimo Labs

## Observe and Troubleshoot

For use with the Instruqt:

https://play.instruqt.com/manage/prosimo/

Challenges:
* Review Architecture and Discover Networks
* Build Multi-Coud Transit
* Observe Multi-Cloud Interconnectivity
* Troubleshoot Multi-Cloud Networking


## Secure Cloud Resources

For use with the Instruqt:

https://play.instruqt.com/manage/prosimo/

Challenges:
* Review Architecture and Discover Networks
* Build Multi-Coud Transit
* Build Policies

